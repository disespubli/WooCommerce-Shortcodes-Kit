=== Woo Shortcodes Kit ===
Contributor: Disespubli
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=LAU9U6B795VV8
Tags: commerce, e-commerce, ecommerce, sales, sell, downloads, orders, count, shipping, shop, stock, store, wordpress, ecommerce, sales counter, WooCommerce shortcodes kit, Requires at least: 4.5
Tested up to: 4.4.1
Stable tag: 1.0

"Woo Shortcodes Kit" is a kit of shortcodes and sales counter module, only created for WooCommerce plugin.

== Description ==

"Woo Shortcodes Kit" does not work alone. It is originally created for WooCommerce (https://wordpress.org/plugins/woocommerce/), so before install "Woo Shortcodes Kit" you must have need to install WooCommerce on your website.

== Installation ==

In most cases you can install automatically from WordPress.

However, if you install this manually, follow these steps:

1. Upload the entire `wc shortcodes kit` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.



== Frequently Asked Questions ==

= How Configure the the "Woo Shortcodes Kit"? =

Go to "Settings >> Woo Shortcodes Kit" and configure the plugin settings.




For more see screenshots.


== Screenshots ==

1. screenshot-1.jpeg

2. screenshot-2.jpeg



== Changelog ==

= 1.0 = 
 * First stable release 

