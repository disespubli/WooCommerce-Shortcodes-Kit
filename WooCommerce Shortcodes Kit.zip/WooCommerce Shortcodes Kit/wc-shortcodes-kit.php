<?php

/*
  Plugin Name: WooCommerce Shortcodes Kit
  Plugin URI: http://disespubli.com/woocommerce-shortcodes-kit
  Description: Easy shortcodes which can be displayed on any page or post to show user purchase orders , downloads and total products count.
  Author: Alberto G.
  Version: 1.0
  Author URI: http://disespubli.com
  Text Domain: WooCommerce Shortcodes Kit
  Domain Path: /languages
  License: GPL2

    Woocommerce Shortcodes Kit is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    any later version.
 
    Woocommerce Shortcodes Kit is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
 
    You should have received a copy of the GNU General Public License
    along with Woocommerce Shortcodes Kit. If not, see https://www.gnu.org/licenses/gpl-2.0.html.
  */

    //Let's go!

    /* register admin menu */
    add_action('admin_menu','register_wc_shortcodes_kit');
if(!function_exists('register_wc_shortcodes_kit')):
function register_wc_shortcodes_kit()
{
    add_options_page('WooCommerce Shortcodes Kit','WooCommerce Shortcodes Kit','manage_options','wc-shortcodes-kit','init_wc_shortcodes_kit_admin_page_html');
    }
endif;

if(!function_exists('wcsk_add_settings_link')):
// Add settings link to plugin list page in admin
        function wcsk_add_settings_link( $links ) {
            $settings_link = array('<a href="options-general.php?page=wc-shortcodes-kit">' . __( 'Settings', 'wcsk' ) . '</a>');
            return array_merge( $links, $settings_link );;
        } 
endif;
$plugin = plugin_basename( __FILE__ );
add_filter( "plugin_action_links_$plugin", 'wcsk_add_settings_link' );
/** register settings */
if(!function_exists('wcsk_register_settings')):
function wcsk_register_settings() {
    register_setting( 'wcsk_options', 'wcsk_enable');
    register_setting( 'wcsk_options', 'wcsk-inlinecss');
    register_setting( 'wcsk_options', 'wcsk_text'); 
} 
add_action( 'admin_init', 'wcsk_register_settings' );
endif;

/** Define plugin settings page html */
if(!function_exists('init_wc_shortcodes_kit_admin_page_html')):
function init_wc_shortcodes_kit_admin_page_html()
{
    //esto es para la caja de .css
    if(get_option('wcsk-inlinecss')!='')
{
    $inlineCss=get_option('wcsk-inlinecss');
    }else
    {
    $inlineCss='.wc-sk {width: 50%;}
.wc-sk .wc-sk-count{ 
    color:#a46497;font-weight:bold;font-size:18px;
    }
.wc-sk .wc-sk-text {font-size: 12px;}';
        }
?>
<div style="width: 80%; padding: 10px; margin: 10px;"> 
 <h1>WooCommerce Shortcodes Kit</h1>
 <!-- Start Options Form -->
 <form action="options.php" method="post" id="wcsk-sidebar-admin-form">    
 <div id="wcsk-tab-menu"><a id="wcsk-general" class="wcsk-tab-links active" >General</a> <a  id="wcsk-support" class="wcsk-tab-links">Support</a> 
 </div>
<div class="wcsk-setting">
    <!-- General Setting -->    
    <div class="first wcsk-tab" id="div-wcsk-general">
    <h2>General Settings</h2>
    <p><input type="checkbox" id="wcsk_enable" name="wcsk_enable" value='1' <?php if(get_option('wcsk_enable')!=''){ echo ' checked="checked"'; }?>/><label> Enable Product Downloads Sales/ Count</label></p>
    <p><label> Text:</label> <input type="text" id="wcsk_text" name="wcsk_text" value="<?php if(get_option('wcsk_text')!=''){ echo get_option('wcscm_text'); }?>" placeholder="Sales/Downloads"/ size="40"></p>
    </div>
    <!-- Support -->
    <div class="last author wcsk-tab" id="div-wcsk-support">
    <h2>Plugin Support</h2>
    <table>
    <tr>
    <td width="50%" ><p><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=LAU9U6B795VV8" target="_blank" style="font-size: 17px; font-weight: bold;"><img src="https://www.paypal.com/en_US/i/btn/btn_donate_LG.gif" title="Donate for this plugin"></a></p>
    <p><strong>Plugin Documentation:</strong><br><img src="<?php echo  plugins_url( 'images/wcsk.jpg' , __FILE__ );?>" class="authorimg"><br><a href="http://disespubli.com" target="_blank">DISESPUBLI</a></p>
    <p><a href="mailto:disespubli@gmail.com" target="_blank" class="contact-author">Contact Author</a></p></td>
    <td><p><strong>Shortcodes:</strong><br>
    <ul>
        <li><p>If you want show user purchase orders, use this Shortcode: [my_orders]</p></li>
        <li><p>If you want show user downloads, use this Shortcode: [my_downloads]</p></li>
        <li><p>If you want show the total products count, use this Shortcode: [my_products]</p></li>
                </ul></p></td>
    </tr>
    </table>
    </div>
    </div>
        <span class="submit-btn"><?php echo get_submit_button('Save Settings','button-primary','submit','','');?></span>
    <?php settings_fields('wcsk_options'); ?>
    </form>
<!-- End Options Form -->
</div>
<?php
}
endif;
/** add js into admin footer */
// better use get_current_screen(); or the global $current_screen
if (isset($_GET['page']) && $_GET['page'] == 'wc-shortcodes-kit') {
   add_action('admin_footer','init_wcsk_admin_scripts');
}

if(!function_exists('init_wcsk_admin_scripts')):
function init_wcsk_admin_scripts()
{
wp_register_style( 'wcsk_admin_style', plugins_url( 'css/wcsk-admin-min.css',__FILE__ ) );
wp_enqueue_style( 'wcsk_admin_style' );

echo $script='<script type="text/javascript">
    /* Protect WP-Admin js for admin */
    jQuery(document).ready(function(){
        jQuery(".wcsk-tab").hide();
        jQuery("#div-wcsk-general").show();
        jQuery(".wcsk-tab-links").click(function(){
        var divid=jQuery(this).attr("id");
        jQuery(".wcsk-tab-links").removeClass("active");
        jQuery(".wcsk-tab").hide();
        jQuery("#"+divid).addClass("active");
        jQuery("#div-"+divid).fadeIn();
        });
        })
    </script>';
}
endif;

/** register_deactivation_hook */
/** Delete exits options during deactivation the plugins */
if( function_exists('register_deactivation_hook') ){
   register_deactivation_hook(__FILE__,'init_deactivation_wcsk_plugins');   
}

//Delete all options after uninstall the plugin
if(!function_exists('init_deactivation_wcsk_plugins')):
function init_deactivation_wcsk_plugins(){
    delete_option('wcsk_enable');
    delete_option('wcsk_text');
    delete_option('wcsk-inlinecss');
    
}
endif;
/** register_activation_hook */
/** Delete exits options during activation the plugins */
if( function_exists('register_activation_hook') ){
   register_activation_hook(__FILE__,'init_activation_wcsk_plugins');   
}

//Disable free version after activate the plugin
if(!function_exists('init_activation_wcsk_plugins')):
function init_activation_wcsk_plugins(){
    delete_option('wcsk_enable');
    delete_option('wcsk_text');
    delete_option('wcsk-inlinecss');
}
endif;

/** Include class file **/
require dirname(__FILE__).'/wc-sk-class.php';
?>