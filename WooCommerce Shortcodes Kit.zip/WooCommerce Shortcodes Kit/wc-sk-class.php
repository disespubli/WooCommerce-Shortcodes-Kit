<?php
/*
 * WooCommerce Shortcodes Kit
 * @get_cf7as_sidebar_options()
 * @get_cf7as_sidebar_content()
 * */
 ?>
<?php

/* WOOCOMMERCE PURCHASE ORDERS */
//If you want show user purchase orders on any page or post, use this Shortcode: [my_orders]

function shortcode_my_orders( $atts ) {
    extract( shortcode_atts( array(
        'order_count' => -1
    ), $atts ) );

    ob_start();
    wc_get_template( 'myaccount/my-orders.php', array(
        'current_user'  => get_user_by( 'id', get_current_user_id() ),
        'order_count'   => $order_count
    ) );
    return ob_get_clean();
}
add_shortcode('my_orders', 'shortcode_my_orders');

/* WOOCOMMERCE USER DOWNLOADS */
//If you want show user downloads on any page or post, use this Shortcode: [my_downloads]

function shortcode_my_downloads( $atts ) {
    extract( shortcode_atts( array(
        'downloads' => -1
    ), $atts ) );

    ob_start();
    wc_get_template( 'myaccount/downloads.php', array(
        'current_user'  => get_user_by( 'id', get_current_user_id() ),
        'downloads'   => $downloads
    ) );
    return ob_get_clean();
}
add_shortcode('my_downloads', 'shortcode_my_downloads');

/* WOOCOMMERCE TOTAL PRODUCT COUNT */
//If you want to show total products on any page or post, use this Shortcode: [my_products]

function get_productcount( $atts ) {
    extract( shortcode_atts( array(
        'product_count' => 0
    ), $atts ) );

    // loop through all categories to collect the count.
   foreach (get_terms('product_cat') as $term)
      $product_count += $term->count;

   return $product_count;
}

add_shortcode('my_products', 'get_productcount');

/* TOTAL PRODUCT SALES/DOWNLOADS COUNT FUNCTION*/ 
// get all options value for "Custom Share Buttons with Floating Sidebar"

	function get_wc_sk_sidebar_options() {
		global $wpdb;
		$ctOptions = $wpdb->get_results("SELECT option_name, option_value FROM $wpdb->options WHERE option_name LIKE 'wcsk_%'");				
		foreach ($ctOptions as $option) {
			$ctOptions[$option->option_name] =  $option->option_value;
		}
		return $ctOptions;	
	}
	// Get plugin options
global $pluginOptionsVal;
$pluginOptionsVal=get_wc_sk_sidebar_options();
/** Start Sales Counter Code */
if(isset($pluginOptionsVal['wcsk_enable']) && $pluginOptionsVal['wcsk_enable']==1)
{
	/* Start Sales Count Code */
  if(!function_exists('wc_sk_product_sold_count')):
	add_action( 'woocommerce_single_product_summary', 'wc_sk_product_sold_count', 11 );
	add_action( 'woocommerce_after_shop_loop_item', 'wc_sk_product_sold_count', 11 );
function wc_sk_product_sold_count() {
		global $product;
		$pluginOptionsVal=get_wc_sk_sidebar_options();
		if(isset($pluginOptionsVal['wcsk_text']) && $pluginOptionsVal['wcsk_text']!='')
		{
			$salesTxt=$pluginOptionsVal['wcsk_text'];
			}else {
				$salesTxt="Sales";
				}
		$units_sold = get_post_meta( $product->id, 'total_sales', true );
		echo '<p class="wc-sk">' . sprintf( __( '<span class="wc-sk-count">%s</span> <span class="wc-sk-text">%s</span>', 'woocommerce' ), $units_sold,$salesTxt ) . '</p>';
	}
  endif;
  add_action('wp_head','add_wc_sk_inline_style');
	/** counter css */
	if(!function_exists('add_wc_sk_inline_style')):
	function add_wc_sk_inline_style()
	{
		$pluginOptionsVal=get_wc_sk_sidebar_options();
		$wcsk_style='<style>'.$pluginOptionsVal['wcsk-inlinecss'].'</style>';
		print $wcsk_style;
		}
	endif;
}
