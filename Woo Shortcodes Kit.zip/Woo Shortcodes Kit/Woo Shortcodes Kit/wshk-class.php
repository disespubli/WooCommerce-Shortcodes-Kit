<?php
/*
 * Woo Shortcodes Kit
 * @get_cf7as_sidebar_options()
 * @get_cf7as_sidebar_content()
 * */
 ?>
<?php

/* WOO MY ORDERS LIST */
//If you want show user purchase orders on any page or post, use this Shortcode: [woo_orders_list]

function wshk_my_orders_list( $atts ) {
    extract( shortcode_atts( array(
        'order_count' => -1
    ), $atts ) );

    ob_start();
    wc_get_template( 'myaccount/my-orders.php', array(
        'current_user'  => get_user_by( 'id', get_current_user_id() ),
        'order_count'   => $order_count
    ) );
    return ob_get_clean();
}
add_shortcode('woo_orders_list', 'wshk_my_orders_list');

/* WOO USER DOWNLOADS LIST */
//If you want show user downloads on any page or post, use this Shortcode: [woo_downloads_list]

function wshk_my_downloads_list( $atts ) {
    extract( shortcode_atts( array(
        'downloads' => -1
    ), $atts ) );

    ob_start();
    wc_get_template( 'myaccount/downloads.php', array(
        'current_user'  => get_user_by( 'id', get_current_user_id() ),
        'downloads'   => $downloads
    ) );
    return ob_get_clean();
}
add_shortcode('woo_downloads_list', 'wshk_my_downloads_list');

/* WOO TOTAL PRODUCT COUNTER */
//If you want to show total products on any page or post, use this Shortcode: [woo_total_products_counter]

function wshk_my_product_count( $atts ) {
    extract( shortcode_atts( array(
        'product_count' => 0
    ), $atts ) );

    // loop through all categories to collect the count.
   foreach (get_terms('product_cat') as $term)
      $product_count += $term->count;

   return $product_count;
}

add_shortcode('woo_total_products_counter', 'wshk_my_product_count');

/* WOO GLOBAL ORDERS/ DOWNLOADS COUNTER */
// If you want to show the global orders/downloads count on any page or post, use this Shortcode: [woo_global_sales]

function wshk_my_global_sales() {

global $wpdb;

$order_totals = apply_filters( 'woocommerce_reports_sales_overview_order_totals', $wpdb->get_row( "

SELECT SUM(meta.meta_value) AS total_sales, COUNT(posts.ID) AS total_orders FROM {$wpdb->posts} AS posts

LEFT JOIN {$wpdb->postmeta} AS meta ON posts.ID = meta.post_id

WHERE meta.meta_key = '_order_total'

AND posts.post_type = 'shop_order'

AND posts.post_status IN ( '" . implode( "','", array( 'wc-completed', 'wc-processing', 'wc-on-hold' ) ) . "' )

" ) );

return absint( $order_totals->total_orders);

}
add_shortcode('woo_global_sales', 'wshk_my_global_sales');



/* INDIVIDUAL PRODUCT SALES/DOWNLOADS COUNT FUNCTION*/ 
// If you want to show the invididual product sales/downloads with a  automatic counter just need a clic

	function get_wshk_sidebar_options() {
		global $wpdb;
		$ctOptions = $wpdb->get_results("SELECT option_name, option_value FROM $wpdb->options WHERE option_name LIKE 'wshk_%'");				
		foreach ($ctOptions as $option) {
			$ctOptions[$option->option_name] =  $option->option_value;
		}
		return $ctOptions;	
	}
	// Get plugin options
global $pluginOptionsVal;
$pluginOptionsVal=get_wshk_sidebar_options();
/** Start Sales Counter Code */
if(isset($pluginOptionsVal['wshk_enable']) && $pluginOptionsVal['wshk_enable']==1)
{
	/* Start Sales Count Code */
  if(!function_exists('wshk_product_sold_count')):
	add_action( 'woocommerce_single_product_summary', 'wshk_product_sold_count', 11 );
	add_action( 'woocommerce_after_shop_loop_item', 'wshk_product_sold_count', 11 );
function wshk_product_sold_count() {
		global $product;
		$pluginOptionsVal=get_wshk_sidebar_options();
		if(isset($pluginOptionsVal['wshk_text']) && $pluginOptionsVal['wshk_text']!='')
		{
			$salesTxt=$pluginOptionsVal['wshk_text'];
			}else {
				$salesTxt="Sales";
				}
		$units_sold = get_post_meta( $product->id, 'total_sales', true );
		echo '<p class="wshk">' . sprintf( __( '<span class="wshk-count">%s</span> <span class="wshk-text">%s</span>', 'woocommerce' ), $units_sold,$salesTxt ) . '</p>';
	}
  endif;
  add_action('wp_head','add_wshk_inline_style');
	/** counter css */
	if(!function_exists('add_wshk_inline_style')):
	function add_wshk_inline_style()
	{
		$pluginOptionsVal=get_wshk_sidebar_options();
		$wshk_style='<style>'.$pluginOptionsVal['wshk-inlinecss'].'</style>';
		print $wshk_style;
		}
	endif;
}
