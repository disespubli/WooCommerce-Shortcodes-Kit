<?php

/*
  Plugin Name: Woo Shortcodes Kit
  Plugin URI: http://disespubli.com/woo-shortcodes-kit
  Description: Easy shortcodes which can be displayed on any page or post to show user purchase orders , downloads and total products count. This plugin not work alone, you need install WooCommerce before.
  Author: Alberto G.
  Version: 1.0
  Author URI: http://disespubli.com
  Text Domain: Woo Shortcodes Kit
  Domain Path: /languages
  License: GPL2

    Woo Shortcodes Kit is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    any later version.
 
    Woo Shortcodes Kit is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.
 
    You should have received a copy of the GNU General Public License
    along with Woocommerce Shortcodes Kit. If not, see https://www.gnu.org/licenses/gpl-2.0.html.
  */

    //Let's go!

    /* register admin menu */
    add_action('admin_menu','register_woo_shortcodes_kit');
if(!function_exists('register_woo_shortcodes_kit')):
function register_woo_shortcodes_kit()
{
    add_options_page('Woo Shortcodes Kit','Woo Shortcodes Kit','manage_options','woo-shortcodes-kit','init_woo_shortcodes_kit_admin_page_html');
    }
endif;

if(!function_exists('wshk_add_settings_link')):
// Add settings link to plugin list page in admin
        function wshk_add_settings_link( $links ) {
            $settings_link = array('<a href="options-general.php?page=woo-shortcodes-kit">' . __( 'Settings', 'wshk' ) . '</a>');
            return array_merge( $links, $settings_link );;
        } 
endif;
$plugin = plugin_basename( __FILE__ );
add_filter( "plugin_action_links_$plugin", 'wshk_add_settings_link' );
/** register settings */
if(!function_exists('wshk_register_settings')):
function wshk_register_settings() {
    register_setting( 'wshk_options', 'wshk_enable');
    register_setting( 'wshk_options', 'wshk-inlinecss');
    register_setting( 'wshk_options', 'wshk_text'); 
} 
add_action( 'admin_init', 'wshk_register_settings' );
endif;

/** Define plugin settings page html */
if(!function_exists('init_woo_shortcodes_kit_admin_page_html')):
function init_woo_shortcodes_kit_admin_page_html()
{
    //esto es para la caja de .css
    if(get_option('wshk-inlinecss')!='')
{
    $inlineCss=get_option('wshk-inlinecss');
    }else
    {
    $inlineCss='.wshk {width: 50%;}
.wshk .wshk-count{ 
    color:#a46497;font-weight:bold;font-size:18px;
    }
.wshk .wshk-text {font-size: 12px;}';
        }
?>
<div style="width: 80%; padding: 10px; margin: 10px;"> 
 <h1>Woo Shortcodes Kit</h1>
 <!-- Start Options Form -->
 <form action="options.php" method="post" id="wshk-sidebar-admin-form">    
 <div id="wshk-tab-menu"><a id="wshk-general" class="wshk-tab-links active" >General</a> <a  id="wshk-support" class="wshk-tab-links">Shortcodes & Support</a> 
 </div>
<div class="wshk-setting">
    <!-- General Setting -->    
    <div class="first wshk-tab" id="div-wshk-general">
    <h2>General Settings</h2>
    <p><input type="checkbox" id="wshk_enable" name="wshk_enable" value='1' <?php if(get_option('wshk_enable')!=''){ echo ' checked="checked"'; }?>/><label> Enable Product Downloads/Sales Counter</label></p>
    <p><label> Text/Html:</label> <input type="text" id="wshk_text" name="wshk_text" value="<?php if(get_option('wshk_text')!=''){ echo get_option('wshk_text'); }?>" placeholder="Downloads/Sales"/ size="40"></p>
    </div>
    <!-- Support -->
    <div class="last author wshk-tab" id="div-wshk-support">
    <h2>Plugin Support</h2>
    <table>
    <tr>
    <td width="50%" ><p><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=LAU9U6B795VV8" target="_blank" style="font-size: 17px; font-weight: bold;"><img src="https://www.paypal.com/en_US/i/btn/btn_donate_LG.gif" title="Donate for this plugin"></a></p>
    <p><strong>Plugin Documentation:</strong><br><img src="<?php echo  plugins_url( 'images/wshk.jpg' , __FILE__ );?>" class="authorimg"><br><a href="http://disespubli.com" target="_blank">DISESPUBLI</a></p>
    <p><a href="mailto:disespubli@gmail.com" target="_blank" class="contact-author">Contact Author</a></p></td>
    <td><p><strong>Shortcodes:</strong><br>
    <ul>
        <li><p>If you want show user purchase orders, use this Shortcode: <strong>[woo_orders_list]</strong></p></li>
        <li><p>If you want show user downloads, use this Shortcode: <strong>[woo_downloads_list]</strong></p></li>
        <li><p>If you want show the total products counter, use this Shortcode: <strong>[woo_total__products_counter]</strong></p></li>
        <li><p>If you want show the global sales/downloads counter use this shortcode: <strong>[woo_global_sales]</strong></p></li>
                </ul></p></td>
    </tr>
    </table>
    </div>
    </div>
        <span class="submit-btn"><?php echo get_submit_button('Save Settings','button-primary','submit','','');?></span>
    <?php settings_fields('wshk_options'); ?>
    </form>
<!-- End Options Form -->
</div>
<?php
}
endif;
/** add js into admin footer */
// better use get_current_screen(); or the global $current_screen
if (isset($_GET['page']) && $_GET['page'] == 'woo-shortcodes-kit') {
   add_action('admin_footer','init_wshk_admin_scripts');
}

if(!function_exists('init_wshk_admin_scripts')):
function init_wshk_admin_scripts()
{
wp_register_style( 'wshk_admin_style', plugins_url( 'css/wshk-admin-min.css',__FILE__ ) );
wp_enqueue_style( 'wshk_admin_style' );

echo $script='<script type="text/javascript">
    /* Protect WP-Admin js for admin */
    jQuery(document).ready(function(){
        jQuery(".wshk-tab").hide();
        jQuery("#div-wshk-general").show();
        jQuery(".wshk-tab-links").click(function(){
        var divid=jQuery(this).attr("id");
        jQuery(".wshk-tab-links").removeClass("active");
        jQuery(".wshk-tab").hide();
        jQuery("#"+divid).addClass("active");
        jQuery("#div-"+divid).fadeIn();
        });
        })
    </script>';
}
endif;

/** register_deactivation_hook */
/** Delete exits options during deactivation the plugins */
if( function_exists('register_deactivation_hook') ){
   register_deactivation_hook(__FILE__,'init_deactivation_wshk_plugins');   
}

//Delete all options after uninstall the plugin
if(!function_exists('init_deactivation_wshk_plugins')):
function init_deactivation_wshk_plugins(){
    delete_option('wshk_enable');
    delete_option('wshk_text');
    delete_option('wshk-inlinecss');
    
}
endif;
/** register_activation_hook */
/** Delete exits options during activation the plugins */
if( function_exists('register_activation_hook') ){
   register_activation_hook(__FILE__,'init_activation_wshk_plugins');   
}

//Disable free version after activate the plugin
if(!function_exists('init_activation_wshk_plugins')):
function init_activation_wshk_plugins(){
    delete_option('wshk_enable');
    delete_option('wshk_text');
    delete_option('wshk-inlinecss');
}
endif;

/** Include class file **/
require dirname(__FILE__).'/wshk-class.php';
?>